package cn.jiyun.util;

import cn.jiyun.pojo.Student;

import java.util.ArrayList;
import java.util.List;

public class Util {

    public static List<Student> getTestDate(){
        ArrayList<Student> list = new ArrayList<>();
        list.add(new Student("1","大数据","1000"));
        list.add(new Student("2","人工智能","900"));
        list.add(new Student("3","全栈开发","800"));
        list.add(new Student("4","物联网","700"));
        list.add(new Student("5","UI","400"));

        return list;
    }
}
