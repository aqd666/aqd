package cn.jiyun.pojo;

public class Student {
    private String id;
    private String profession;
    private String count;

    public Student(String id, String profession, String count) {
        this.id = id;
        this.profession = profession;
        this.count = count;
    }

    public Student() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
